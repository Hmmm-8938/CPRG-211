﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Creating_Classes_Lab
{
    internal class Person
    {
        public int personID { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string favoriteColour { get; set; }
        public int age { get; set; }
        public bool isWorking { get; set; }

        public Person(int personID, string firstName, string lastName, string favoriteColour, int age, bool isWorking)
        {
            this.personID = personID;
            this.firstName = firstName;
            this.lastName = lastName;
            this.favoriteColour = favoriteColour;
            this.age = age;
            this.isWorking = isWorking;
        }

        public void displayPersonInfo()
        {
            Console.WriteLine($"{personID}: {firstName} {lastName}'s favorite colour is {favoriteColour}");
        }

        public void changeFavoriteColour()
        {
            this.favoriteColour = "White";
        }

        public void getAgeInTenYears()
        {
            int age10 = age += 10;
            Console.WriteLine($"{firstName} {lastName}'s age in 10 years is: {age10}");
        }

        public override string ToString()
        {
            return ($"\nPersonID: {personID}\nFirst Name: {firstName}\nLast Name: {lastName}\nFavoriteColour: {favoriteColour}\nAge: {age}\nIs Working?: {isWorking}");
        }
    }
}
