﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Creating_Classes_Lab
{
    internal class Relation : Person
    {
        public Person individual1 { get; set; }
        public Person individual2 { get; set; }
        public Relate relater { get; set; }
      
        public Relation(Person individual1, Person individual2, Relate relater):base(0, "First", "Last", "ColourFav", 0, false)
        {
            this.relater = relater;
        }
        public enum Relate
        {
            Sisterhood, Brotherhood, Motherhood, Fatherhood
        }
        public void showRelation()
        {
            Console.WriteLine($"Relation between {individual1.firstName} and {individual2.firstName} is: {relater}");
        }
    }
}
