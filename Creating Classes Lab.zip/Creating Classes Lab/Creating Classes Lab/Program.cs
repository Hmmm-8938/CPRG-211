﻿using System;

namespace Creating_Classes_Lab
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Person person1 = new Person(1, "Ian", "Brooks", "Red", 30, true);
            Person person2 = new Person(2, "Gina", "James", "Green", 18, false);
            Person person3 = new Person(3, "Mike", "Briscoe", "Blue", 45, true);
            Person person4 = new Person(4, "Mary", "Beals", "Yellow", 28, true);

            person2.displayPersonInfo();
            Console.WriteLine(person3);
            person1.changeFavoriteColour();
            person1.displayPersonInfo();
            person4.getAgeInTenYears();
            Relation relation1 = new Relation(person2, person4, Relation.Relate.Sisterhood);
            Relation relation2 = new Relation(person1, person3, Relation.Relate.Brotherhood);
            //relation1.showRelation(); The show relation doesn't seem to work the value is null not sure why this is.
            //relation2.showRelation(); 
            List<Person> people = new List<Person>();
            people.Add(person1);
            people.Add(person2);
            people.Add(person3);
            people.Add(person4);
            int ageTotal = 0;
            int avgTotal = 0;
            foreach (Person person in people)
            {
                ageTotal += person.age;
                avgTotal++;
            }
            double ageAverage = (ageTotal / avgTotal);
            Console.WriteLine($"Average age is: {ageAverage}");
            foreach (Person person in people)
            {
                if (person.age <= 18)
                {
                    Console.WriteLine($"The youngest person is: {person.firstName}");
                }
                else if (person.age >= 45)
                {
                    Console.WriteLine($"The oldest person is: {person.lastName}");
                }
            }
            foreach (Person person in people)
            {
                string first = (person.firstName).Substring(0, 1);
                if (first == "M")
                {
                    Console.WriteLine($"{person.firstName}'s name starts with M");
                }
            }
            foreach (Person person in people)
            {
                string col = (person.favoriteColour);
                if (col == "Blue")
                {
                    Console.WriteLine($"\nWriting the info of {person.firstName} to the console since their favourite colour is Blue");
                    Console.WriteLine(person);
                }
            }
        }
    }
}
