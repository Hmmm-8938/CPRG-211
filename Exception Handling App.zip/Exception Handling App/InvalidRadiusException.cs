﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception_Handling_App
{
    internal class InvalidRadiusException : Exception
    {
        public InvalidRadiusException() 
        {
            Console.WriteLine("Default message: Radius is less than or equal to zero");
        }
        public InvalidRadiusException(string message, double radius) : base(message)
        {
            Console.WriteLine($"The Radius of {radius} is invalid!");
        }
    }
}