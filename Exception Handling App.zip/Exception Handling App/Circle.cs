﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception_Handling_App
{
    internal class Circle
    {
        private double radius { get; set; }
        public Circle()
        {

        }

        public Circle(double radius)
        {
            this.radius = radius;
        }

        public void setRadius(double radius)
        {
            if (radius > 0)
            {
                this.radius = radius;
                double radiusValue = radius;
            }
            else if (radius <= 0)
            {
                throw new InvalidRadiusException("Radius Invalid!", radius);
            }
        }

        public override string ToString()
        {
            return ($"Radius: {radius}");
        }
    }
}
