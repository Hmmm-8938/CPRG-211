﻿namespace Exception_Handling_App
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Circle positiveCircle = new Circle(10);
            Circle negativeCircle = new Circle(-10);
            Circle zeroCircle = new Circle(0);
            try
            {
                positiveCircle.setRadius(10);
                Console.WriteLine(positiveCircle.ToString());
            }
            catch (InvalidRadiusException e)
            {
                Console.WriteLine("If a message is printed here something is brutally wrong with the code!");
            }

            try
            {
                negativeCircle.setRadius(-10);
            }
            catch (InvalidRadiusException e)
            {}

            try
            {
                zeroCircle.setRadius(0);
            }
            catch (InvalidRadiusException e)
            { }
        }
    }
}
