using System.IO;
namespace Lab01;
class Lab01
{
    static void Main(string[] args)
    {
        //int low = lowInputValidation();
        double low = lowInputValidation();
        //int high = highInputValidation(low);
        double high = highInputValidation(low);
        //Console.WriteLine("Please enter a low number that is greater than 0");
        //int low = int.Parse(Console.ReadLine());
        //while (low < 0)
        //{
        //    Console.WriteLine($"You have input the number {low} which is less than the minimum of 0");
        //    Console.WriteLine("Please enter a new low number that is greater than 0");
        //    low = int.Parse(Console.ReadLine());
        //}
        //Console.WriteLine("Please enter a high number");
        //int high = int.Parse(Console.ReadLine());
        //while (high < low)
        //{
        //    Console.WriteLine($"You have input the high number {high} which is less than the low number of {low}");
        //    Console.WriteLine($"Please enter a new high number that is greater than the low number {low}");
        //    high = int.Parse(Console.ReadLine());
        //}
        //int difference = high - low;
        double difference = high - low;
        Console.WriteLine($"The difference between the low number {low} and the high number {high} is {difference}");
        //int[] highLow = new int[difference];
        //double[] highLow = new double[(int)difference];
        List<double> highLow = new List<double>();
        //int differenceChange = high - 1;
        double differenceChange = high - 1;
        Console.WriteLine($"The numbers between the high number {high} and the low number {low} are as follows and if the number is prime: \n");
        for (int i = 0; i < difference-1; i++)
        {
        highLow.Add(differenceChange);
        differenceChange -= 1;
        primeNum(highLow[i]);
        }
        using (StreamWriter sw = new StreamWriter("C:\\Users\\Benjamin Mellott\\iCloudDrive\\My_Files\\School\\Software_Development_SAIT\\Semester_2\\CPRG-211__Object_Oriented_Programming_2__G\\Lab 01\\Lab 01\\numbers.txt"))
        {
            //foreach (int number in highLow)
            foreach (double number in highLow)
            {
                sw.WriteLine(number);
            }
        }
        string data;
        StreamReader reader = null;
        reader = new StreamReader("C:\\Users\\Benjamin Mellott\\iCloudDrive\\My_Files\\School\\Software_Development_SAIT\\Semester_2\\CPRG-211__Object_Oriented_Programming_2__G\\Lab 01\\Lab 01\\numbers.txt");
        data = reader.ReadLine();
        Console.WriteLine("Read back from the file here are the numbers.");
        double total = 0;
        while (data != null)
        {
            total = (total + (double.Parse(data)));
            Console.WriteLine(data);
            data = reader.ReadLine();
        }
        Console.WriteLine($"The total of the numbers read back from the file is {total}");
        Console.ReadKey();
    }

        //static int lowInputValidation()
    static double lowInputValidation()
    {
        Console.WriteLine("Please enter a low number that is greater than 0");
        //int low = int.Parse(Console.ReadLine());
        double low = double.Parse(Console.ReadLine());
        while (low <= 0)
        {
            Console.WriteLine($"You have input the number {low} which is less than the minimum of 0");
            Console.WriteLine("Please enter a new low number that is greater than 0");
            //low = int.Parse(Console.ReadLine());
            low = double.Parse(Console.ReadLine());
        }
        return low;
    }

    //static int highInputValidation(int low)
    static double highInputValidation(double low)
    {
        Console.WriteLine("Please enter a high number");
        //int high = int.Parse(Console.ReadLine());
        double high = double.Parse(Console.ReadLine());
        while (high < low)
        {
            Console.WriteLine($"You have input the high number {high} which is less than the low number of {low}");
            Console.WriteLine($"Please enter a new high number that is greater than the low number {low}");
            // high = int.Parse(Console.ReadLine());
            high = double.Parse(Console.ReadLine());
        }
        return high;
    }

    static double primeNum(double input)
    {
        double divisors = 0;
        for (int i = 1; i <= input; i++)
        {
            if (input % i == 0)
            {
                divisors++;
            }
        }
        if (divisors == 2)
        {
            Console.WriteLine($"{input} ---- PRIME");
        }
        else
        {
            Console.WriteLine($"{input} ---- NOT PRIME");
        }
        return 0;
    }
}