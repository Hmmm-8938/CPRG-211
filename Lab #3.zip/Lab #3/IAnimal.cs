﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab__3
{
    internal interface IAnimal
    {
        void Eat();
        void Cry();
    }

    class DogInterface : IAnimal
    {
        public string dogName;
        public int dogHeight;
        public string dogColour;
        public int dogAge;
        public DogInterface(string dogName, int dogHeight, string dogColour, int dogAge)
        {
            this.dogName = dogName;
            this.dogHeight = dogHeight;
            this.dogColour = dogColour;
            this.dogAge = dogAge;
        }
        public void Eat() 
        {
            Console.WriteLine("Dogs eat meat");
        }
        public void Cry() 
        {
            Console.WriteLine("Woof!");
        }
    }

    class CatInterface : IAnimal
    {
        public string catName;
        public int catHeight;
        public string catColour;
        public int catAge;
        public CatInterface(string catName, int catHeight, string catColour, int catAge)
        {
            this.catName = catName;
            this.catHeight = catHeight;
            this.catColour = catColour;
            this.catAge = catAge;
        }
        public void Eat()
        {
            Console.WriteLine("Cats eat mice");
        }
        public void Cry() 
        {
            Console.WriteLine("Meow!");
        }
    }
}
