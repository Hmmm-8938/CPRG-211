﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab__3
{
    public abstract class Animal
    {
        public string Name { get; set; }
        public string Colour { get; set; }
        public int Age { get; set; }

        public abstract void Eat();

        public Animal()
        {

        }

        public Animal(string Name, string Colour, int Age)
        {
            this.Name = Name;
            this.Colour = Colour;
            this.Age = Age;
        }
    }
}
