﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab__3
{
    public class Cat : Animal
    {
        public Cat() 
        {
        
        }
        
        public Cat(string Name, string Colour, int Age)
        {
            this.Name = Name;
            this.Colour = Colour;
            this.Age = Age;
        }

        public override void Eat()
        {
            Console.WriteLine("Cats eat mice.");
        }
    }
}
