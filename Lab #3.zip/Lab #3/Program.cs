﻿namespace Lab__3
{
    internal class Program
    {
        static void Main(string[] args)
        {
               Console.WriteLine("PART #1\n******************************\n");
               Console.WriteLine("Give me a name for a Dog.");
               String dogname = Console.ReadLine();
               Console.WriteLine("Give me a colour for a Dog");
               String dogcolour = Console.ReadLine();
               Console.WriteLine("Give me a age for a Dog");
               int dogage = int.Parse(Console.ReadLine());
               Console.WriteLine("Give me a name for a Cat.");
               String catname = Console.ReadLine();
               Console.WriteLine("Give me a colour for a Cat");
               String catcolour = Console.ReadLine();
               Console.WriteLine("Give me a age for a Cat");
               int catage = int.Parse(Console.ReadLine());
               Dog dog = new Dog(dogname, dogcolour, dogage);
               Cat cat = new Cat(catname, catcolour, catage);
               Console.WriteLine($"\n\n***********************\n\nDog Details:\n\nName: {dog.Name}\nColour: {dog.Colour}\nAge: {dog.Age}\n\n***************************\n\nCat Details:\n\nName: {cat.Name}\nColour: {cat.Colour}\nAge: {cat.Age} \n\n");
               dog.Eat();
               cat.Eat();


               Console.WriteLine("\n\n\n\n\nPart #2\n******************************\n");
               Console.WriteLine("Give me a name for a Dog");
               String iDogName = Console.ReadLine();
               Console.WriteLine("Give me a height for a Dog");
               int iDogHeight = int.Parse(Console.ReadLine());
               Console.WriteLine("Give me a colour for a Dog");
               String iDogColour = Console.ReadLine();
               Console.WriteLine("Give me a age for a Dog");
               int iDogAge = int.Parse(Console.ReadLine());
               Console.WriteLine("Give me a name for a Cat");
               String iCatName = Console.ReadLine();
               Console.WriteLine("Give me a height for a Cat");
               int iCatHeight = int.Parse(Console.ReadLine());
               Console.WriteLine("Give me a colour for a Cat");
               String iCatColour = Console.ReadLine();
               Console.WriteLine("Give me a age for a Cat");
               int iCatAge = int.Parse(Console.ReadLine());
               DogInterface iDog = new DogInterface(iDogName, iDogHeight, iDogColour, iDogAge);
               CatInterface iCat = new CatInterface(iCatName, iCatHeight, iCatColour, iCatAge);
               Console.WriteLine($"\n\n***********************\n\nDog Details:\n\nName: {iDog.dogName}\nHeight: {iDog.dogHeight}\nColour: {iDog.dogColour}\nAge: {iDog.dogAge}\n\n***************************\n\nCat Details:\n\nName: {iCat.catName}\nHeight: {iCat.catHeight}\nColour: {iCat.catColour}\nAge: {iCat.catAge}\n\n");
               iDog.Eat();
               iDog.Cry();
               iCat.Eat();
               iCat.Cry();

               Console.WriteLine("\n\nAnimals List:\n\n");

               List<IAnimal> animalListDogs = new List<IAnimal>();
               DogInterface iDog1 = new DogInterface("Digsby", 20, "Brown/Black", 5);
               DogInterface iDog2 = new DogInterface("Pepper", 10, "White", 15);
               DogInterface iDog3 = new DogInterface("Bailey", 30, "Black/Brown", 5);
               animalListDogs.Add(iDog1);
               animalListDogs.Add(iDog2);
               animalListDogs.Add(iDog3);
               foreach(DogInterface animalDogs in animalListDogs)
               {
                    Console.WriteLine(animalDogs.dogName);
               }

               List<IAnimal> animalListCats = new List<IAnimal>();
               CatInterface iCat1 = new CatInterface("Jynx", 10, "Black", 5);
               CatInterface iCat2 = new CatInterface("Smokey", 10, "Grey", 7);
               CatInterface iCat3 = new CatInterface("Sunny", 10, "Orange/White", 10);
               animalListCats.Add(iCat1);
               animalListCats.Add(iCat2);
               animalListCats.Add(iCat3);
               foreach (CatInterface animalCats in animalListCats)
               { 
                   Console.WriteLine(animalCats.catName);
               }
        }
    }
}
