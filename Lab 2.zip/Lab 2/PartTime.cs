﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Lab_2
{
    internal class PartTime : Employee
    {
        public double rate { get; set; }
        public double hours { get; set; }
        public PartTime()
        {

        }
        public PartTime(string id, string name, string address, string phone, long sin, string dob, string dept, double rate, double hours)
        {
            this.id = id;
            this.name = name;
            this.address = address;
            this.phone = phone;
            this.sin = sin;
            this.dob = dob;
            this.dept = dept;
            this.rate = rate;
            this.hours = hours;
        }
        public void getPay()
        {
        }

        public override string ToString()
        {
            return ($"Part Time Employee Details\n*******************\n\nID: {id}\nNAME: {name}\nADDRESS: {address}\nPHONE: {phone}\nSIN: {sin}\nDOB: {dob}\nDEPT: {dept}\nRATE: {rate}\nHOURS: {hours}");
        }
    }
}
