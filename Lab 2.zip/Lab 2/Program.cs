﻿using System.Xml.Linq;

namespace Lab_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string data;
            StreamReader reader = null;
            reader = new StreamReader("C:\\Users\\Benjamin Mellott\\Desktop\\Lab 2\\res\\employees.txt");
            double employeeTotal = 0;
            double salariedTotal = 0;
            double wageTotal = 0;
            double partTimeTotal = 0;
            double companyPayWeekly = 0;
            List<Employee> employees = new List<Employee>();
            List<Wages> wages = new List<Wages>();
            List<Salaried> salaried = new List<Salaried>();
            data = reader.ReadLine();
            while (data != null)
            {
                string res = data.Substring(0, 1);
                if (String.Equals(res, "0"))
                {
                    string[] strings = data.Split(":");
                    long sin = long.Parse(strings[4]);
                    double salary = double.Parse(strings[7]);
                    employees.Add(new Salaried(strings[0], strings[1], strings[2], strings[3], sin, strings[5], strings[6], salary));
                    salaried.Add(new Salaried(strings[0], strings[1], strings[2], strings[3], sin, strings[5], strings[6], salary));
                    salariedTotal++;
                    companyPayWeekly = companyPayWeekly + salary;
                }
                else if (String.Equals(res, "1"))
                {
                    string[] strings = data.Split(":");
                    long sin = long.Parse(strings[4]);
                    double salary = double.Parse(strings[7]);
                    employees.Add(new Salaried(strings[0], strings[1], strings[2], strings[3], sin, strings[5], strings[6], salary));
                    salaried.Add(new Salaried(strings[0], strings[1], strings[2], strings[3], sin, strings[5], strings[6], salary));
                    salariedTotal++;
                    companyPayWeekly = companyPayWeekly + salary;
                }
                else if (String.Equals(res, "2"))
                {
                    string[] strings = data.Split(":");
                    long sin = long.Parse(strings[4]);
                    double salary = double.Parse(strings[7]);
                    employees.Add(new Salaried(strings[0], strings[1], strings[2], strings[3], sin, strings[5], strings[6], salary));
                    salaried.Add(new Salaried(strings[0], strings[1], strings[2], strings[3], sin, strings[5], strings[6], salary));
                    salariedTotal++;
                    companyPayWeekly = companyPayWeekly + salary;
                }
                else if (String.Equals(res, "3"))
                {
                    string[] strings = data.Split(":");
                    long sin = long.Parse(strings[4]);
                    double salary = double.Parse(strings[7]);
                    employees.Add(new Salaried(strings[0], strings[1], strings[2], strings[3], sin, strings[4], strings[5], salary));
                    salaried.Add(new Salaried(strings[0], strings[1], strings[2], strings[3], sin, strings[5], strings[6], salary));
                    salariedTotal++;
                    companyPayWeekly = companyPayWeekly + salary;
                }
                else if (String.Equals(res, "4"))
                {
                    string[] strings = data.Split(":");
                    long sin = long.Parse(strings[4]);
                    double salary = double.Parse(strings[7]);
                    employees.Add(new Salaried(strings[0], strings[1], strings[2], strings[3], sin, strings[5], strings[6], salary));
                    salaried.Add(new Salaried(strings[0], strings[1], strings[2], strings[3], sin, strings[5], strings[6], salary));
                    salariedTotal++;
                    companyPayWeekly = companyPayWeekly + salary;
                }
                else if (String.Equals(res, "5"))
                {
                    string[] strings = data.Split(":");
                    long sin = long.Parse(strings[4]);
                    double rate = double.Parse(strings[7]);
                    double hours = double.Parse(strings[8]);
                    employees.Add(new Wages(strings[0], strings[1], strings[2], strings[3], sin, strings[5], strings[6], rate, hours));
                    wages.Add(new Wages(strings[0], strings[1], strings[2], strings[3], sin, strings[5], strings[6], rate, hours));
                    while (hours > 40)
                    {
                        double timeHalf = rate * 1.5;
                        companyPayWeekly = companyPayWeekly + timeHalf;
                        hours--;
                    }
                    double employeeEarnings = (rate * hours);
                    companyPayWeekly = companyPayWeekly + employeeEarnings;
                    wageTotal++;
                }
                else if (String.Equals(res, "6"))
                {
                    string[] strings = data.Split(":");
                    long sin = long.Parse(strings[4]);
                    double rate = double.Parse(strings[7]);
                    double hours = double.Parse(strings[8]);
                    employees.Add(new Wages(strings[0], strings[1], strings[2], strings[3], sin, strings[5], strings[6], rate, hours));
                    wages.Add(new Wages(strings[0], strings[1], strings[2], strings[3], sin, strings[5], strings[6], rate, hours));
                    while (hours > 40)
                    {
                        double timeHalf = rate * 1.5;
                        companyPayWeekly = companyPayWeekly + timeHalf;
                        hours--;
                    }
                    double employeeEarnings = (rate * hours);
                    companyPayWeekly = companyPayWeekly + employeeEarnings;
                    wageTotal++;
                }
                else if (String.Equals(res, "7"))
                {
                    string[] strings = data.Split(":");
                    long sin = long.Parse(strings[4]);
                    double rate = double.Parse(strings[7]);
                    double hours = double.Parse(strings[8]);
                    employees.Add(new Wages(strings[0], strings[1], strings[2], strings[3], sin, strings[5], strings[6], rate, hours));
                    wages.Add(new Wages(strings[0], strings[1], strings[2], strings[3], sin, strings[5], strings[6], rate, hours));
                    while (hours > 40)
                    {
                        double timeHalf = rate * 1.5;
                        companyPayWeekly = companyPayWeekly + timeHalf;
                        hours--;
                    }
                    double employeeEarnings = (rate * hours);
                    companyPayWeekly = companyPayWeekly + employeeEarnings;
                    wageTotal++;
                }
                else if (String.Equals(res, "8"))
                {
                    string[] strings = data.Split(":");
                    long sin = long.Parse(strings[4]);
                    double rate = double.Parse(strings[7]);
                    double hours = double.Parse(strings[8]);
                    employees.Add(new PartTime(strings[0], strings[1], strings[2], strings[3], sin, strings[5], strings[6], rate, hours));
                    double employeeEarnings = (rate * hours);
                    companyPayWeekly = companyPayWeekly + employeeEarnings;
                    partTimeTotal++;
                }
                else if (String.Equals(res, "9"))
                {
                    string[] strings = data.Split(":");
                    long sin = long.Parse(strings[4]);
                    double rate = double.Parse(strings[7]);
                    double hours = double.Parse(strings[8]);
                    employees.Add(new PartTime(strings[0], strings[1], strings[2], strings[3], sin, strings[5], strings[6], rate, hours));
                    double employeeEarnings = (rate * hours);
                    companyPayWeekly = companyPayWeekly + employeeEarnings;
                    partTimeTotal++;
                }
                employeeTotal++;
                data = reader.ReadLine();
            }
            double averageWeeklyCompany = (companyPayWeekly / employeeTotal);
            double pay = 0;
            double largest = 0;
            string wageLargestName = "";
            foreach (Wages waged in wages)
            {
                while (waged.hours > 40)
                {
                    pay = pay + (waged.rate * 1.5);
                    waged.hours--;
                }
                pay = pay + (waged.rate * waged.hours);
                if (pay > largest)
                {
                    largest = pay;
                    wageLargestName = waged.name;
                }
            }
            double smallest = 999999999;
            string salariedSmallestName = "";
            foreach (Salaried salarys in salaried)
            {
                if (salarys.salary < smallest)
                {
                    smallest = salarys.salary;
                    salariedSmallestName = salarys.name;
                }
            }
            double salaryPercent = ((salariedTotal/employeeTotal) * 100);
            double wagePercent = ((wageTotal/employeeTotal) * 100);
            double partTimePercent = ((partTimeTotal/employeeTotal) * 100);
            Console.WriteLine($"The average weekly pay for all employees is... ${(String.Format("{0:0.##}", averageWeeklyCompany))}");
            Console.WriteLine($"The highest weekly pay for the wage employee {wageLargestName} is ${(String.Format("{0:0.##}", largest))}");
            Console.WriteLine($"The lowest weekly pay for the salaried employee {salariedSmallestName} is ${(String.Format("{0:0.##}", smallest))}");
            Console.WriteLine($"\nPercentage of Employees in each category\n********************************************\n\nSalaried Employees = {(String.Format("{0:0.##}", salaryPercent))}%\nWage Employees = {(String.Format("{0:0.##}", wagePercent))}%\nPartTime Employees = {(String.Format("{0:0.##}", partTimePercent))}%");
        }
    }
}
