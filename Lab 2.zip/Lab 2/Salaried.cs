﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_2
{
    internal class Salaried : Employee
    {
        public double salary { get; set; }

        public Salaried() 
        {

        }

        public Salaried(string id, string name, string address, string phone, long sin, string dob, string dept, double salary)
        {
            this.id = id;
            this.name = name;
            this.address = address;
            this.phone = phone;
            this.sin = sin;
            this.dob = dob;
            this.dept = dept;
            this.salary = salary;
        }

        public double getPay()
        {
            return 0;
        }
        public override string ToString()
        {
            return ($"Salaried Employee Details\n*******************\n\nID: {id}\nNAME: {name}\nADDRESS: {address}\nPHONE: {phone}\nSIN: {sin}\nDOB: {dob}\nDEPT: {dept}\nSALARY: {salary}");
        }

    }
}
