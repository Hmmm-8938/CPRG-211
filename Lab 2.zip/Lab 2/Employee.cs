﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_2
{
    internal class Employee
    {
        public string id { get; set; }
        public string name { get; set; }
        public string address { get; set; }
        public string phone { get; set; }
        public long sin { get; set; }
        public string dob { get; set; }
        public string dept { get; set; }

        public Employee()
        {

        }

        public Employee (string id, string name, string address, string phone, long sin, string dob, string dept)
        {
            this.id = id;
            this.name = name;
            this.address = address;
            this.phone = phone;
            this.sin = sin;
            this.dob = dob;
            this.dept = dept;
        }

        public override string ToString()
        {
            return ($"Employee Details\n*******************\n\nID: {id}\nNAME: {name}\nADDRESS: {address}\nPHONE: {phone}\nSIN: {sin}\nDOB: {dob}\nDEPT: {dept}");
        }
    }
}
