﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_2
{
    internal class Wages : Employee
    {
        public double rate { get; set; }
        public double hours { get; set; } 
        public Wages()
        {

        }
        public Wages(string id, string name, string address, string phone, long sin, string dob, string dept, double rate, double hours)
        {
            this.id = id;
            this.name = name;
            this.address = address;
            this.phone = phone;
            this.sin = sin;
            this.dob = dob;
            this.dept = dept;
            this.rate = rate;
            this.hours = hours;
        }
        public void getPay()
        {

        }

        public override string ToString()
        {
            return ($"Wage Employee Details\n*******************\n\nID: {id}\nNAME: {name}\nADDRESS: {address}\nPHONE: {phone}\nSIN: {sin}\nDOB: {dob}\nDEPT: {dept}\nRATE: {rate}\nHOURS: {hours}");
        }
    }
}
