﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

/* 
Assignment 1: Classes and Inheritance
Group 7: Benjamin Mellott, Jaxson Burdett, Joshua Rustulka, Shannon Hilland
Date: Feb 13, 2024
The appliance class is the base class for all appliances. 
It contains all the shared properties of the child classes. 
It also contains the virtual methods for each child class to override, as well as the checkout method to update the quantity 
of the appliance when the customer checks an appliance out.
*/

namespace OOP2Assignment1
{
    public abstract class Appliance
    {
        public int ItemNumber { get; set; }
        public string Brand { get; set; }
        public int Quantity { get; set; }
        public int Wattage { get; set; }
        public string Color { get; set; }
        public double Price { get; set; }

        public Appliance()
        {

        }


        public Appliance(int itemNumber, string brand, int quantity, int wattage, string color, double price)
        {
            this.ItemNumber = itemNumber;
            this.Brand = brand;
            this.Quantity = quantity;
            this.Wattage = wattage;
            this.Color = color;
            this.Price = price;
        }

     
        public virtual string formatForFile()
        {
            return $"{ItemNumber};{Brand};{Quantity};{Wattage};{Color};{Price}";
        }

        public override string ToString()
        {
            return ($"\n\nItem Number: {ItemNumber}\nBrand: {Brand}\nQuantity: {Quantity}\nWattage: {Wattage}\nColor: {Color}\nPrice: {Price}\n");
        }

        public bool IsAvailable
        {
            get
            {
                if (Quantity > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public enum ApplianceTypes
        {
            unknown,
            Refrigerator = 1,
            Vacuum = 2,
            Microwave = 3,
            Dishwasher = 4
        }

        /*This function accepts an interger representing an item's ID. It will then check which number the string starts with. 
         * After it does so It will return the appropriate string */
        public string DetermineApplianceTypeFromItemNumber(int itemNum)
        {
            string ID = itemNum.ToString();
            if (ID.StartsWith("1"))
            {
                return "Refrigerator";
            }
            else if (ID.StartsWith("2"))
            {
                return "Vacuum";
            }
            else if (ID.StartsWith("3"))
            {
                return "Microwave";
            }
            else if (ID.StartsWith("4") || ID.StartsWith("5"))
            {
                return "Dishwasher";
            }
            else
            {
                return "";
            }
        }

        public string ApplianceType
        {
            get
            {
                return DetermineApplianceTypeFromItemNumber(ItemNumber);
            }
        }


        /*
   The checkout method checks if a given appliance is available (quantity is greater than zero), and if it is, will decrement the quanity of that appliance by one, and return true.
        If the appliance is not available, it will return false.
   */
        public bool Checkout()
        {
            if (IsAvailable == true)
            {
                Quantity -= 1;
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}