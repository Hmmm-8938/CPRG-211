﻿using System;

/*
Assignment 1: Classes and Inheritance
Group 7: Benjamin Mellott, Jaxson Burdett, Joshua Rustulka, Shannon Hilland
Date: Feb 13, 2024
The program allows the user to upload a list of appliances and creates a list of objects from that document. 
The user can checkout an appliance based on item number, find appliances based on brand, display appliances based on appliance type and display a random list of appliances. 
It also saves the appliances when exiting the program.
*/

namespace OOP2Assignment1
{ 
  public class Program
  {
        /*
        The main functions creates a modernAppliance, which creates the list of appliance objects in the class ModernAppliance.
        It then displays the main menu and loops through until the user selects to exit the program. 
        Each selection will call a method from the MyModernAppliances class to execute before returning to the loop.
        */
        static void Main(string[] args)
        {
            ModernAppliances modernAppliances = new MyModernAppliances();

            int userInputInt = 0;

            while (userInputInt != 5)
            {
                modernAppliances.DisplayMenu();
                Console.WriteLine("\nEnter Option:");
                string userInput = Console.ReadLine();
                if (userInput.Equals("1") || userInput.Equals("2") || userInput.Equals("3") || userInput.Equals("4") || userInput.Equals("5"))
                {
                    userInputInt = int.Parse(userInput);
                    if (userInputInt == 1)
                    {
                        modernAppliances.Checkout();
                    }
                    else if (userInputInt == 2)
                    {
                        modernAppliances.Find();
                    }
                    else if (userInputInt == 3)
                    {
                        modernAppliances.DisplayType();
                    }
                    else if (userInputInt == 4)
                    {
                        modernAppliances.RandomList();
                    }
                    else if (userInputInt == 5)
                    {
                        modernAppliances.save();

                    }
                    else
                    {
                        Console.WriteLine("Invalid option entered. Please try again.");
                    }
                }
            } 
    }
  }
}