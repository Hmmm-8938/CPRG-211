﻿using System;
using System.Collections.Generic;

/* 
Assignment 1: Classes and Inheritance
Group 7: Benjamin Mellott, Jaxson Burdett, Joshua Rustulka, Shannon Hilland
Date: Feb 13, 2024
The RandomComparer Class takes in two values which then proceeds to compare the value of the 2 numbers. 
Comparing the values and then randomly determines if one value should be placed before or after the other value.
*/

namespace OOP2Assignment1
{
    internal class RandomComparer : IComparer<Appliance>
    {
        private readonly Random random = new Random();

        public int Compare(Appliance x, Appliance y)
        {
            if (x == y)
            {
                return 0;
            }

            return random.Next(-1, 1);
        }

    }

}
