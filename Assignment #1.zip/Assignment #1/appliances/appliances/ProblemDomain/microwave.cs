﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using OOP2Assignment1;

/*
Assignment 1: Classes and Inheritance
Group 7: Benjamin Mellott, Jaxson Burdett, Joshua Rustulka, Shannon Hilland
Date: Feb 13, 2024
The Microwave Class is a child class of the Appliance class and inherits from it. 
It has the additional properties and constant of capacity and roomtype.
*/

namespace appliances.ProblemDomain
{

    public class Microwave : Appliance
    {
        public double Capacity { get; set; }
        public string RoomType { get; set; }
        public const string ROOMTYPEKITCHEN = "K";
        public const string ROOMTYPEWORKSITE = "W";

        public Microwave()
        {

        }

        public Microwave(int itemNumber, string brand, int quantity, int wattage, string color, double price, double capacity, string roomType)
        {
            ItemNumber = itemNumber;
            Brand = brand;
            Quantity = quantity;
            Wattage = wattage;
            Color = color;
            Price = price;
            Capacity = capacity;
            RoomType = roomType;
        }

        public string RoomTypeDisplay
        {
            get
            {
                switch (RoomType)
                {
                    case ROOMTYPEKITCHEN:
                        return "Kitchen";
                    case ROOMTYPEWORKSITE:
                        return "Work Site";
                    default:
                        return "(Unknown)";
                }
            }
        }
        
        public override string formatForFile()
        {
            return $"{ItemNumber};{Brand};{Quantity};{Wattage};{Color};{Price};{Capacity};{RoomType}";
        }

        public override string ToString()
        {
            return $"\n\nItem Number: {ItemNumber}\nBrand: {Brand}\nQuantity: {Quantity}\nWattage {Wattage}\nColor: {Color}\nPrice: {Price}\nCapacity: {Capacity}\nRoom Type: {RoomType}\n";
        }
    }
}

