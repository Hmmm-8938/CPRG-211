﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using OOP2Assignment1;

/*
Assignment 1: Classes and Inheritance
Group 7: Benjamin Mellott, Jaxson Burdett, Joshua Rustulka, Shannon Hilland
Date: Feb 13, 2024
The Refrigerator class is a child class of the Appliance class and inherits from it. 
It has the unique additional properties and constants of doors, height and width.
*/

namespace appliances.ProblemDomain
{

    public class Refrigerator : Appliance
    {
        public int Doors { get; set; }
        public int Height { get; set; }
        public int Width { get; set; }

        public Refrigerator()
        {

        }

        public Refrigerator(int itemNumber, string brand, int quantity, int wattage, string color, double price, int doors, int height, int width)
        {
            ItemNumber = itemNumber;
            Brand = brand;
            Quantity = quantity;
            Wattage = wattage;
            Color = color;
            Price = price;
            Doors = doors;
            Height = height;
            Width = width;
        }

     
        public override string formatForFile()
        {
            return $"{ItemNumber};{Brand};{Quantity};{Wattage};{Color};{Price};{Doors};{Height};{Width}";
        }

        public override string ToString()
        {
            return $"\n\nItem Number: {ItemNumber}\nBrand: {Brand}\nQuantity: {Quantity}\nWattage: {Wattage}\nColor: {Color}\nPrice: {Price}\nDoors: {Doors}\nHeight: {Height}\nWidth: {Width}\n";
        }
    }
}