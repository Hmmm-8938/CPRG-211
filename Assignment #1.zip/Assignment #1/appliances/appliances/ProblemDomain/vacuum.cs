﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using OOP2Assignment1;

/*
Assignment 1: Classes and Inheritance
Group 7: Benjamin Mellott, Jaxson Burdett, Joshua Rustulka, Shannon Hilland
Date: Feb 13, 2024
The Vacuum class is a child class of the Appliance class and inherits from it. 
It has the additional properties and constants of grade and Battery voltage of the vacuum.
*/

namespace appliances.ProblemDomain
{
    public class Vacuum : Appliance
    {
        public int BatteryVoltage { get; set; }
        public string Grade { get; set; }

        public Vacuum()
        {

        }

        public Vacuum(int itemNumber, string brand, int quantity, int wattage, string color, double price, string grade, int batteryVoltage)
        {
            ItemNumber = itemNumber;
            Brand = brand;
            Quantity = quantity;
            Wattage = wattage;
            Color = color;
            Price = price;
            Grade = grade;
            BatteryVoltage = batteryVoltage;
        }

       
        public override string formatForFile()
        {
            return $"{ItemNumber};{Brand};{Quantity};{Wattage};{Color};{Price};{Grade};{BatteryVoltage}";
        }

        public override string ToString()
        {
            return $"\n\nItem Number: {ItemNumber}\nBrand: {Brand}\nQuantity: {Quantity}\nWattage: {Wattage}\nColor: {Color}\nPrice: {Price}\nGrade: {Grade}\nBattery Voltage: {BatteryVoltage}\n";
        }
    }
}

