﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using OOP2Assignment1;

/*
Assignment 1: Classes and Inheritance
Group 7: Benjamin Mellott, Jaxson Burdett, Joshua Rustulka, Shannon Hilland
Date: Feb 13, 2024
The Dishwasher class is a child class of the Appliance class and inherits from it.
It has additional properties and methods specific to the dishwasher. 
It also contains constants to describe the sound rating and overrides the Appliance class formatForFile and ToString methods.
*/

namespace appliances.ProblemDomain
{

    public class Dishwasher : Appliance
    {
        public string Feature { get; set; }
        public string SoundRating { get; set; }
        public const string SOUNDRATINGQUIETEST = "Qt";
        public const string SOUNDRATINGQUIETER = "Qr";
        public const string SOUNDRATINGQUIET = "Qu";
        public const string SOUNDRATINGMODERATE = "M";

        public Dishwasher()
        {

        }

        public Dishwasher(int itemNumber, string brand, int quantity, int wattage, string color, double price, string feature, string soundRating)
        {
            ItemNumber = itemNumber;
            Brand = brand;
            Quantity = quantity;
            Wattage = wattage;
            Color = color;
            Price = price;
            Feature = feature;
            SoundRating = soundRating;
        }

       
        public override string formatForFile()
        {
            return $"{ItemNumber};{Brand};{Quantity};{Wattage};{Color};{Price};{Feature};{SoundRating}";
        }

        public string SoundRatingDisplay
        {
            get
            {
                switch (SoundRating)
                {
                    case SOUNDRATINGQUIETEST:
                        return "Quietest";
                    case SOUNDRATINGQUIETER:
                        return "Quieter";
                    case SOUNDRATINGQUIET:
                        return "Quiet";
                    case SOUNDRATINGMODERATE:
                        return "Moderate";
                    default:
                        return "(Unknown)";
                }
            }
        }

        public override string ToString()
        {
            return $"\n\nItem Number: {ItemNumber}\nBrand: {Brand}\nQuantity: {Quantity}\nWattage: {Wattage}\nColor: {Color}\nPrice: {Price}\nFeature: {Feature}\nSound Rating: {SoundRating}\n";
        }
    }
}

