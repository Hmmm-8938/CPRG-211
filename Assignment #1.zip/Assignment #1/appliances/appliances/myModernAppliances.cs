﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using appliances.ProblemDomain;

/*
Assignment 1: Classes and Inheritance
Group 7: Benjamin Mellott, Jaxson Burdett, Joshua Rustulka, Shannon Hilland
Date: Feb 13, 2024
The MyModernAppliances is a child class of the ModernAppliances class and inherits from it. 
It contains all the main menu functions that the main function runs including, checking out an item, finding appliances by brand,
sorting and displaying appliances by type, producing random appliance list and saving and exit.
*/

namespace OOP2Assignment1
{
    /*This method asks the user for a item number, matches it to any item number in the Appliance list and then checkouts 
     * and prints the corresponding appliance.*/
    public class MyModernAppliances : ModernAppliances
    {
        public override void Checkout()
        {
            Console.WriteLine("Enter the item number of an appliance:");
            long itemNum = long.Parse(Console.ReadLine());
            Appliance foundAppliance;
   
            foundAppliance = null;
            
            foreach (Appliance appliance in Appliances)
            {
                if (itemNum == appliance.ItemNumber)
                {
                    foundAppliance = appliance;
                    break;
                }
            }
            if (foundAppliance == null)
            {
                Console.WriteLine("No appliances found with that item number.");
            }
           
            else
            {
                bool isAvailable = foundAppliance.Checkout();
                if (isAvailable == true)
                {
                    Console.WriteLine($"Appliance '{itemNum}' has been checked out.");
                }
                else
                {
                    Console.WriteLine("The appliance is not available to be checked out.");
                }
            }
        }

        /*This method prompts the user for a brand and then proceeds to match and print the appliance
         * information for any matching brands.*/
        public override void Find()
        {
            Console.WriteLine("Enter brand to search for: ");
            string entered = Console.ReadLine();

            string enteredBrand = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(entered);

            List<Appliance> brandAppliances = new List<Appliance>();
   
            foreach (Appliance appliance in Appliances)
            {
                if (appliance.Brand == enteredBrand)
                {
                    brandAppliances.Add(appliance);
                }
            }
  
            DisplayAppliancesFromList(brandAppliances, 0);
        }

        /*
    The RandomList method will ask the user for the type of appliances and a number of
        appliances to produce and then will produce a random list of appliances of that number specified.
     */
        public override void RandomList()
        {
            Console.WriteLine("Appliance Types");
            Console.WriteLine("0 - Any\n1 - Refrigertors\n2 - Vacuums\n3 - Microwaves\n4 - Dishwashers");
            Console.WriteLine("Enter type of appliance: ");
            string applianceType = Console.ReadLine();
            if (applianceType != "0" && applianceType != "1" && applianceType != "2" && applianceType != "3" && applianceType != "4")
            {
                Console.WriteLine("Invalid input, please enter an integer shown above");
                applianceType = Console.ReadLine();
            }
            Console.WriteLine("Enter number of appliances");
            int applianceNum = int.Parse(Console.ReadLine());
            List<Appliance> randomList = new List<Appliance>();
            switch (applianceType)
            {
                case "0":
                    {
                        foreach (Appliance appliance in Appliances)
                        {
                            randomList.Add(appliance);
                        }
                        break;
                    }
                case "1":
                    {
                        foreach (Appliance appliance in Appliances)
                        {
                            if (appliance.ApplianceType == "Refrigerator")
                            {
                                randomList.Add(appliance);
                            }
                        }
                        break;
                    }
                case "2":
                    {
                        foreach (Appliance appliance in Appliances)
                        {
                            if (appliance.ApplianceType == "Vacuum")
                            {
                                randomList.Add(appliance);
                            }
                        }
                        break;
                    }
                case "3":
                    {
                        foreach (Appliance appliance in Appliances)
                        {
                            if (appliance.ApplianceType == "Microwave")
                            {
                                randomList.Add(appliance);
                            }
                        }
                        break;
                    }
                case "4":
                    {
                        foreach (Appliance appliance in Appliances)
                        {
                            if (appliance.ApplianceType == "Dishwasher")
                            {
                                randomList.Add(appliance);
                            }
                        }
                        break;
                    }
            }
            randomList.Sort(new RandomComparer());

            int i = 0;
            while (i < applianceNum)
            {
                Console.WriteLine(randomList[i].ToString() + "\n");
                i++;
            }


        }
        /*This method will display a menu prompting the user to enter the desired number of doors. 
        After that, it will sort through the appliance list and verify all refrigerators meeting the criteria. 
        Then it will iterate through the refigeratorsFound list and verify that they are refrigerators. 
         * Lastly it will display all valid refrigerators*/
        public override void DisplayRefrigerators()
        {
            Console.WriteLine("Enter number of doors: 2 (Double Doors), 3 (Three Doors) 4 (Four Doors)");
            string doorsString = Console.ReadLine();
            int doorsInt = int.Parse(doorsString);
            List<Appliance> refrigeratorsFound = new List<Appliance>();
            foreach (Appliance appliance in Appliances)
            {
                if (appliance.ApplianceType == "Refrigerator")
                {
                    refrigeratorsFound.Add(appliance);
                }
            }
            List<Appliance> validatedRefrigerators = new List<Appliance>();
            foreach (Refrigerator refrigerator in refrigeratorsFound)
            {
                if (refrigerator.Doors == doorsInt || refrigerator.Doors == 0)
                {
                    validatedRefrigerators.Add(refrigerator);

                }
            }
            DisplayAppliancesFromList(validatedRefrigerators, 0);
        }
        /*This method will display a menu prompting the user to enter the desired grade. 
         * It will do the same with voltage. After that, it will sort through the appliance list 
         * and verify all vacuums meeting the criteria. 
         * Then it will iterate through the vacuumsFound list and verify that they are vacuums. 
         * Lastly it will display all valid vacuums*/
        public override void DisplayVacuums()
        {
            Console.WriteLine("Possible options: \n1 - Residential\n2 - Commercial\nEnter Grade: ");
            string grade = Console.ReadLine();

            if (grade == "1")
            {
                grade = "Residential";
            }
            else if (grade == "2")
            {
                grade = "Commercial";
            }
            else
            {
                Console.WriteLine("Invalid Option");
                return;
            }

            Console.WriteLine("Enter Battery Voltage: 1 = 18 Volt\n2 = 24 Volt\n  ");
            int voltage = int.Parse(Console.ReadLine());

            if (voltage == 1)
            {
                voltage = 18;
            }
            else if (voltage == 2)
            {
                voltage = 24;
            }
            else
            {
                Console.WriteLine("Invalid Option");
                return;
            }
            List<Appliance> vacuumsFound = new List<Appliance>();
            foreach (Appliance appliance in Appliances)
            {
                if (appliance.ApplianceType == "Vacuum")
                {
                    vacuumsFound.Add(appliance);
                }
            }
            List<Appliance> validatedVacuums = new List<Appliance>();
            foreach (Vacuum vacuum in vacuumsFound)
            {
                if ((vacuum.Grade == grade) && (vacuum.BatteryVoltage == voltage))
                {
                    validatedVacuums.Add(vacuum);

                }
            }
            DisplayAppliancesFromList(validatedVacuums, 0);
        }
        /*This method will display a menu prompting the user to enter the desired room type. 
         * After that, it will sort through the appliance list and verify all microwaves meeting the criteria. 
         * Then it will iterate through the microwavesFound list and verify that they are microwaves. 
         * Lastly it will display all valid microwaves*/
        public override void DisplayMicrowaves()
        {
            Console.WriteLine("Possible options: \n1 - Kitchen\n2 - Work Site\n Enter room type: ");
            string roomType = Console.ReadLine();

            if (roomType == "1")
            {
                roomType = "K";
            }
            else if (roomType == "2")
            {
                roomType = "W";
            }
            else
            {
                Console.WriteLine("Invalid Option");
                return;
            }
            List<Appliance> microwavesFound = new List<Appliance>();
            foreach (Appliance appliance in Appliances)
            {
                if (appliance.ApplianceType == "Microwave")
                {
                    microwavesFound.Add(appliance);
                }
            }
            List<Appliance> validatedMicrowaves = new List<Appliance>();
            foreach (Microwave microwave in microwavesFound)
            {
                if (microwave.RoomType == roomType)
                {
                    validatedMicrowaves.Add(microwave);
                }
            }
            DisplayAppliancesFromList(validatedMicrowaves, 0);
        }
        /*This method will display a menu prompting the user to enter the desired sound rating. 
         * After that, it will sort through the appliance list and verify all dishwashers meeting the criteria. 
         * Then it will iterate through the dishwashersFound
         * list and verify that they are dishwashers. Lastly it will display all valid dishwashers*/
        public override void DisplayDishwashers()
        {
            Console.WriteLine("Possible Options: \n0 - Any\n1 - Quietest\n2 - Quieter\n3 - Quiet\n4 - Moderate\n Enter sound rating: ");
            string soundRating = Console.ReadLine();
            if (soundRating == "1")
            {
                soundRating = "Qt";
            }
            else if (soundRating == "2")
            {
                soundRating = "Qr";
            }
            else if (soundRating == "3")
            {
                soundRating = "Qu";
            }
            else if (soundRating == "4")
            {
                soundRating = "M";
            }
            else
            {
                Console.WriteLine("Invalid Option");
                return;
            }
            List<Appliance> dishwashersFound = new List<Appliance>();
            foreach (Appliance appliance in Appliances)
            {
                if (appliance.ApplianceType == "Dishwasher")
                {
                    dishwashersFound.Add(appliance);
                }
            }
            List<Appliance> validatedDishwashers = new List<Appliance>();
            foreach (Dishwasher dishwasher in dishwashersFound)
            {
                if (dishwasher.SoundRating == soundRating)
                {
                    validatedDishwashers.Add(dishwasher);
                }
            }
            DisplayAppliancesFromList(validatedDishwashers, 0);
        }
    }
}