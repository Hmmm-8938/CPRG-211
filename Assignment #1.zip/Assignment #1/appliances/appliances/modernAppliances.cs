﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using appliances.ProblemDomain;

/*
Assignment 1: Classes and Inheritance
Group 7: Benjamin Mellott, Jaxson Burdett, Joshua Rustulka, Shannon Hilland
Date: Feb 13, 2024
The ModernAppliances class is the abstract base class for the myModernAppliances class. 
It also contains many main methods of the program. It allows the text file to be read and saved to a list. 
It allows that list to be read and create appliances. It also allows the appliances to be displayed.
*/

namespace OOP2Assignment1
{
    public abstract class ModernAppliances
    {
        public const string APPLIANCES_TEXT_FILE = "C:\\Users\\Benjamin Mellott\\Desktop\\appliances\\appliances\\appliances.txt";

        private List<Appliance> appliances;

        public List<Appliance> Appliances
        {
            get
            {
                return new List<Appliance>(appliances);
            }
        }

        /*
        This method is called by the main program and calls the method to read the text file.
        */
        public ModernAppliances()
        {
            this.appliances = this.ReadAppliances();
        }

        /*
       The following methods are overritten in MyModernAppliances
       */
        public abstract void Checkout();
 
        public abstract void Find();
      
        public abstract void RandomList();

        public abstract void DisplayRefrigerators();
        public abstract void DisplayDishwashers();
        public abstract void DisplayVacuums();
        public abstract void DisplayMicrowaves();

        /*
        The CreateAppliance method is called by ReadAppliances method. 
        It takes the line as a paramter and splits it to create an array of items. 
        It checks for the first character of the item number and calls the respective method to create the 
        appliance based on its appliance type. It returns the created appliance to ReadAppliances.
        */
        private Appliance CreateAppliance(string line)
        {
            string[] items = line.Split(';');

            string iDDigit = Char.ToString(line[0]);

            Appliance appliance;

            if (iDDigit == "1")
            {
                
                appliance = CreateRefrigeratorFromParts(items);
            }
            else if (iDDigit == "2")
            {
                
                appliance = CreateVacuumFromParts(items);
            }
            else if (iDDigit == "3")
            {
                
                appliance = CreateMicrowaveFromParts(items);
            }
            else if (iDDigit == "4" || iDDigit == "5")
            {
                
                appliance = CreateDishwasherFromParts(items);
            }
            else
            {
                appliance = null;
            }

            return appliance;
        }

        /*
        The CreateDishwasherFromParts method is called by the CreateAppliance method. 
        It takes the array of items as a parameter and creates a new Dishwasher using the overritten constructor 
        in the Dishwasher class. It then returns the created Dishwasher appliance to CreateAppliance.
        */
        private Dishwasher CreateDishwasherFromParts(string[] items)
        {
            if (items.Length != 8)
                return null;

            int itemNumber = int.Parse(items[0]);
            string brand = items[1];
            int quantity = int.Parse(items[2]);
            int wattage = int.Parse(items[3]);
            string color = items[4];
            double price = double.Parse(items[5]);
            string feature = items[6];
            string soundRating = items[7];

            Dishwasher dishwasher = new Dishwasher(itemNumber, brand, quantity, wattage, color, price, feature, soundRating);

            return dishwasher;
        }

        /*
        The CreateMicrowaveFromParts method is called by the CreateAppliance method. 
        It takes the array of items as a parameter and creates a new Microwave using the overritten constructor 
        in the Microwave class. It then returns the created Microwave to CreateAppliance.
        */
        private Microwave CreateMicrowaveFromParts(string[] items)
        {
            if (items.Length != 8)
                return null;

            int itemNumber = int.Parse(items[0]);
            string brand = items[1];
            int quantity = int.Parse(items[2]);
            int wattage = int.Parse(items[3]);
            string color = items[4];
            double price = double.Parse(items[5]);
            double capacity = double.Parse(items[6]);
            string roomType = items[7];

            Microwave microwave = new Microwave(itemNumber, brand, quantity, wattage, color, price, capacity, roomType);

            return microwave;
        }

        /*
        The CreateRefrigeratorFromParts method is called by the CreateAppliance method. 
        It takes the array of items as a parameter and creates a new Refrigerator using the overritten constructor 
        in the Refrigerator class. It then returns the created Refrigerator to CreateAppliance.
        */
        private Refrigerator CreateRefrigeratorFromParts(string[] items)
        {
            if (items.Length != 9)
                return null;

            int itemNumber = int.Parse(items[0]);
            string brand = items[1];
            int quantity = int.Parse(items[2]);
            int wattage = int.Parse(items[3]);
            string color = items[4];
            double price = double.Parse(items[5]);
            int doors = int.Parse(items[6]);
            int width = int.Parse(items[7]);
            int height = int.Parse(items[8]);

            Refrigerator refrigerator = new Refrigerator(itemNumber, brand, quantity, wattage, color, price, doors, width, height);

            return refrigerator;
        }

        /*
      The CreateVacuumFromParts method is called by the CreateAppliance method. 
        It takes the array of items as a parameter and creates a new Vacuum using the overritten constructor in the Vacuum class.
        It then returns the created Vacuum to CreateAppliance.
      */
        private Vacuum CreateVacuumFromParts(string[] items)
        {
            if (items.Length != 8)
                return null;

            int itemNumber = int.Parse(items[0]);
            string brand = items[1];
            int quantity = int.Parse(items[2]);
            int wattage = int.Parse(items[3]);
            string color = items[4];
            double price = double.Parse(items[5]);
            string grade = items[6];
            int batteryVoltage = int.Parse(items[7]);

            Vacuum vacuum = new Vacuum(itemNumber, brand, quantity, wattage, color, price, grade, batteryVoltage);

            return vacuum;
        }
        
        /*
       The DisplayType method will display a menu prompting the user to enter an appliance type. 
        Then it will call the appropriate method based on the users choice.
     */
        public void DisplayType()
        {
            Console.WriteLine($"Appliance Types\n1 - Refrigerators\n2 - Vaccums\n3 - Microwaves\n4 - Dishwashers\n\nEnter type of appliance: ");
            int applianceTypeNum;
            bool isInt = int.TryParse(Console.ReadLine(), out applianceTypeNum);
            if (!isInt || applianceTypeNum < 0 || applianceTypeNum > 4)
            {
                Console.WriteLine("Invalid Appliance Type has been inputted");
                return;
            }
            else
            {
                if (applianceTypeNum == 1)
                {
                    this.DisplayRefrigerators();
                }
                else if (applianceTypeNum == 2)
                {
                    this.DisplayVacuums();
                }
                else if (applianceTypeNum == 3)
                {
                    this.DisplayMicrowaves();
                }
                else if (applianceTypeNum == 4)
                {
                    this.DisplayDishwashers();
                }
                else
                {
                    Console.WriteLine("Invalid Appliance Type has been inputted");
                }
            }
        }

        /*
     The DisplayAppliancesFromList method takes a list of appliances and a starting index as parameters. 
        It then checks if the list is empty and if it is then will print that no appliances were found. 
        If the list is not empty then it will display the appliances in the list.
     */
        public void DisplayAppliancesFromList(List<Appliance> appliances, int max)
        {
            if (appliances.Count > 0)
            {
                Console.WriteLine("Found appliances:\n");
                for (int i = 0; i < appliances.Count && (max == 0 || i < max); i++)
                {
                    Appliance appliance = appliances[i];
                    Console.WriteLine($"{appliance}\n");
                }
            }
            else
            {
                Console.WriteLine("No appliances found.");
            }
            Console.WriteLine();
        }

        /*
      The DisplayMenu method displays the menu options
      */
        public void DisplayMenu()
        {
            Console.WriteLine("Welcome to Modern Appliances!");
            Console.WriteLine("How May We Assist You?");
            Console.WriteLine("1 – Check out appliance");
            Console.WriteLine("2 – Find appliances by brand");
            Console.WriteLine("3 – Display appliances by type");
            Console.WriteLine("4 – Produce random appliance list");
            Console.WriteLine("5 – Save & exit");
        }

        /*
        The ReadAppliances method reads the appliances from the appliances.txt file. 
        It then creates a list of the appliance objects
        */
        private List<Appliance> ReadAppliances()
        {
            List<Appliance> Appliances = new List<Appliance>();
            string[] lines = File.ReadAllLines(APPLIANCES_TEXT_FILE);
            foreach (string line in lines)
            {
                Appliance appliance = this.CreateAppliance(line);
                if (appliance == null)
                {
                    break;
                }
                else
                {
                    Appliances.Add(appliance);
                }
            }
            return Appliances;
        }

        /*
       The save method will save the list to the file.    
        */
        public void save()
        {
            Console.WriteLine("Saving....");
            StreamWriter fileStream = File.CreateText(APPLIANCES_TEXT_FILE);
            foreach (Appliance appliance in Appliances)
            {
                fileStream.WriteLine(appliance.formatForFile());
            }
            fileStream.Close();
            Console.WriteLine("Saved!");
        }

    }
}
